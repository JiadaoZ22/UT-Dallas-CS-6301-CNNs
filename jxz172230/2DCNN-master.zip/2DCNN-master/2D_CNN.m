classdef 2D_CNN
    %2D_CNN Summary of this class goes here
    %   Detailed explanation goes here
    
    %% propertities
    properties
        input_dataType;
        Pl;
        Pr;
        Pt;
        Pb;
        Ur;
        Us;
        filter_dataType;
        Dr;
        Dc;
        Sr;
        Sc
    end
    
    %% methods
    methods
        %% data generation
        function [inputFeatureMap] = inputFeatureMap_generation(Ni,row,column,input_dataType)
            if isqual(input_dataType,'random')
               inputFeatureMap = randn(Ni,row,column);
            elseif isequal(input_dataType,'sequential')
                count = 0;
                for k=1:Ni
                    for i=1:row
                        for j=1:column
                            inputFeatureMap(k,i,j) = count;
                            count = count + 1;
                        end
                    end
                end
            else
                error('errors with input_dataType!')
            end  
        end
        
        function [filterMap] = inputFeatureMap_generation(No,Ni,row,column,fiter_dataType) 
            if isqual(filter_dataType,'random')
               filterMap = randn(No,Ni,row,column);
            elseif isequal(input_dataType,'sequential')
                count = 0;
                for l=1:No
                    for k=1:Ni
                        for i=1:row
                            for j=1:column
                                filterMap(No,Ni,i,j) = count;
                                count = count + 1;
                            end
                        end
                    end
                end 
            else
                error('errors with filter_dataType!')
            end  
        end
        
        
        %% pre processing
  
        function [new_inputFeatureMap] = inputFeatureMap_upSampling(Ur,Uc,inputFeatureMap)
            [Ni,row,col] = size(inputFeatureMap);
            new_inputFeatureMap = zeros(Ni,Ur*row,Uc*col);
            for i=1:Ni
                for r=1:Ur*row
                    for c=1:col
                        if (r-1)/Ur == 0 && (c-1)/Uc == 0
                            new_inputFeatureMap(Ni,r,c) = inputFeatureMap(Ni,(r-1)/Ur+1,(c-1)/ur+1);
                        end
                    end
                end
            end
        end
        
        
        
        function [inputFeatureMap,filter_dataType] = data_generation(input_dataType,filter_dataType) 
            
        end
        function obj = 2D_CNN(inputArg1,inputArg2)
            %2D_CNN Construct an instance of this class
            %   Detailed explanation goes here
            obj.Property1 = inputArg1 + inputArg2;
        end
        
        function outputArg = method1(obj,inputArg)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            outputArg = obj.Property1 + inputArg;
        end
    end
end

