# 2DCNN
2DCNN

# Data
Please get the demo data from https://pan.baidu.com/s/1slygMPv
