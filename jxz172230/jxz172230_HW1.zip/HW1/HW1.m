% cnn = CNN_2D;
inputFeatureMap = CNN_2D.inputFeatureMap_generation(2,5,5,'sequential');
filterMap = CNN_2D.filter_generation(3,2,3,3,'sequential');
outputFeatureMapConvolution = CNN_2D.outputFeatureMap_ConCalculate(inputFeatureMap,filterMap);
outputFeatureMapMatrix = CNN_2D.outputFeatureMap_MatrixCalculate(inputFeatureMap,filterMap);
%%
disp('InputFeatureMap SEQUENTIAL generated')
disp('______________________________________________________________________________________________________________________________')
disp('outputFeatureMapConvolution:');
disp(outputFeatureMapConvolution);  
disp('outputFeatureMap:')
disp(' ')
disp(outputFeatureMapMatrix) 
%%
inputFeatureMap = CNN_2D.inputFeatureMap_generation(2,5,5,'sequential');
inputFeatureMap = CNN_2D.inputFeatureMap_upSampling(2,2,inputFeatureMap);
outputFeatureMapConvolution = CNN_2D.outputFeatureMap_ConCalculate(inputFeatureMap,filterMap);
outputFeatureMapMatrix = CNN_2D.outputFeatureMap_MatrixCalculate(inputFeatureMap,filterMap);
disp('InputFeatureMap SEQUENTIAL generated, upsampling(2,2)')
disp('______________________________________________________________________________________________________________________________')
disp('outputFeatureMapConvolution:');
disp(outputFeatureMapConvolution);  
disp('outputFeatureMap:')
disp(' ')
disp(outputFeatureMapMatrix)  
%%
inputFeatureMap = CNN_2D.inputFeatureMap_generation(2,5,5,'sequential');
inputFeatureMap = CNN_2D.inputFeatureMap_zeroPadding(1,inputFeatureMap);
outputFeatureMapConvolution = CNN_2D.outputFeatureMap_ConCalculate(inputFeatureMap,filterMap);
outputFeatureMapMatrix = CNN_2D.outputFeatureMap_MatrixCalculate(inputFeatureMap,filterMap);
disp('InputFeatureMap SEQUENTIAL generated, zeropadding(1,1)')
disp('______________________________________________________________________________________________________________________________')
disp('outputFeatureMapConvolution:');
disp(outputFeatureMapConvolution);  
disp('outputFeatureMap:')
disp(' ')
disp(outputFeatureMapMatrix)  
%%
inputFeatureMap = CNN_2D.inputFeatureMap_generation(2,5,5,'sequential');
inputFeatureMap = CNN_2D.inputFeatureMap_zeroPadding(1,inputFeatureMap);
filterMap = CNN_2D.filter_upSampling(1,1,filterMap);
outputFeatureMapConvolution = CNN_2D.outputFeatureMap_ConCalculate(inputFeatureMap,filterMap);
outputFeatureMapConvolution = CNN_2D.outputFeatureMap_downSampling(2,2,outputFeatureMapConvolution);
outputFeatureMapMatrix = CNN_2D.outputFeatureMap_MatrixCalculate(inputFeatureMap,filterMap);
outputFeatureMapMatrix = CNN_2D.outputFeatureMap_downSampling(2,2,outputFeatureMapConvolution);
disp('InputFeatureMap SEQUENTIAL generated, input upsampling(2,2), filter umsampling(1,1), then output downsampling(2,2)')
disp('______________________________________________________________________________________________________________________________')
disp('outputFeatureMapConvolution:');
disp(outputFeatureMapConvolution);  
disp('outputFeatureMap:')
disp(' ')
disp(outputFeatureMapMatrix)  

