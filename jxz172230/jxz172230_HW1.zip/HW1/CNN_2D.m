classdef CNN_2D
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    %% properties
    properties
        inputFeatureMap;
        filterMap
    end
    %% methods
    methods (Static)
        %% data generation
         function [inputFeatureMap] = inputFeatureMap_generation(Ni,row,col,input_dataType)
            if isequal(input_dataType,'random')
               inputFeatureMap = randn(row,col,Ni);
            elseif isequal(input_dataType,'sequential')
                inputFeatureMap = zeros(row,col,Ni);
                count = 0;
                for k=1:Ni
                    for i=1:row
                        for j=1:col
                            inputFeatureMap(i,j,k) = count;
                            count = count + 1;
                        end
                    end
                end
            else
                error('errors with input_dataType!')
            end  
        end
        
        function [filterMap] = filter_generation(No,Ni,row,col,filter_dataType) 
            if isequal(filter_dataType,'random')
               filterMap = randn(row,col,No,Ni);
            elseif isequal(filter_dataType,'sequential')
                filterMap = zeros(row,col,No,Ni);
                count = 0;
                for l=1:No
                    for k=1:Ni
                        for i=1:row
                            for j=1:col
                                filterMap(i,j,l,k) = count;
                                count = count + 1;
                            end
                        end
                    end
                end 
            else
                error('errors with filter_dataType!')
            end  
        end
        
        %% pre processing
        function [new_inputFeatureMap] = inputFeatureMap_upSampling(Ur,Uc,inputFeatureMap)
            [row,col,Ni] = size(inputFeatureMap);
            new_inputFeatureMap = zeros(Ur*row,Uc*col,Ni);
            for i=1:Ni
                for r=1:Ur*row
                    for c=1:Uc*col
                        if mod((r-1),Ur) == 0 && mod((c-1),Uc) == 0
                            new_inputFeatureMap(r,c,i) = inputFeatureMap(floor((r-1)/Ur)+1,floor((c-1)/Uc)+1,i);
                        end
                    end
                end
            end
        end
        
         function [new_inputFeatureMap] = inputFeatureMap_zeroPadding(pad_num,inputFeatureMap)
            [row,col,Ni] = size(inputFeatureMap);
            new_inputFeatureMap = zeros(row+2*pad_num,col+2*pad_num,Ni);
            for i=1:Ni
                for r=1:row+2*pad_num
                    for c=1:col+2*pad_num
                        if (r>pad_num && r<=row+pad_num) && (c>pad_num && c<=col+pad_num)
                            new_inputFeatureMap(r,c,i) = inputFeatureMap(r-pad_num,c-pad_num,i);
                        end
                    end
                end
            end
        end
        
        function [new_filter] = filter_upSampling(Dr,Dc,filterMap)
            [row,col,No,Ni] = size(filterMap);
            new_filter = zeros(Dr*row,Dc*col,No,Ni);
            for j=1:No
                for i=1:Ni
                    for r=1:Dr*row
                        for c=1:Dc*col
                            if mod((r-1),Dr) == 0 && mod((c-1),Dc) == 0
                                new_filter(r,c,No,Ni) = filterMap(floor((r-1)/Dr)+1,floor((c-1)/Dc)+1,j,i);
                            end
                        end
                    end
                end
            end
        end
        
        %% matrix multiplication
        function [outputMatrix] = outputFeatureMap_ConCalculate(inputFeatureMap,filter)
            % now reshape those matrix
            [Lr,Lc,Ni] = size(inputFeatureMap);
            [Fr,Fc,No,Ni] = size(filter);
            Mr = Lr - Fr + 1;
            Mc = Lc - Fc + 1;
            outputMatrix = zeros(Mr,Mc,No);
            for a=1:No
                for b=1:Mr
                    for c=1:Mc
                        for d=1:Ni
                            for e=1:Fr
                                for f=1:Fc
                                    outputMatrix(b,c,a) = outputMatrix(b,c,a) + conv(filter(e,f,a,d),inputFeatureMap(b+e-1,c+f-1,d));
                                end
                            end
                        end
                    end
                end
            end
        end

        function [outputMatrix] = outputFeatureMap_MatrixCalculate(inputFeatureMap,filter)
            % now reshape those matrix
            [Lr,Lc,Ni] = size(inputFeatureMap);
            [Fr,Fc,No,Ni] = size(filter);
            Mr = Lr - Fr + 1;
            Mc = Lc - Fc + 1;
            % transforming inputFeatureMap
            new_inputFeatureMap = zeros(Ni*Fr*Fc,Mr*Mc);
            row_count = 1;
            col_count = 1;
            for ni=1:Ni
                for fr=1:Fr
                    for fc=1:Fc
                        for mr=1:Mr
                            for mc=1:Mc
                                new_inputFeatureMap(row_count,col_count) = inputFeatureMap(mr+fr-1,mc+fc-1,ni);
                                col_count = col_count + 1;
                            end
                        end
                        row_count = row_count + 1;
                        col_count = 1;
                    end
                end
                
            end
            % transforming filterMap
            new_filter = zeros(No,Ni*Fr*Fc);
            row_count = 1;
            col_count = 1;
            for no=1:No
                for ni=1:Ni
                    for fr=1:Fr
                        for fc=1:Fc
                            new_filter(row_count,col_count) = filter(fr,fc,no,ni);
                            col_count = col_count + 1;
                        end
                    end
                end
                row_count =row_count + 1;
                col_count = 1;
            end
                          
            
%             inputFeatureMap = repmat(inputFeatureMap,Fr*Fc,1);
%             inputFeatureMap = reshape(inputFeatureMap,Ni*Fr*Fc,Mr*Mc);
%             filter = reshape(filter,No,Ni*Fr*Fc);
            % multiplication
            outputMatrix = new_filter * new_inputFeatureMap;
        end
        
        %% post processing
        function [new_outputMatrix] = outputFeatureMap_downSampling(Sr,Sc,outputMatrix)
            % downsampling with MAX_Pooling
            [row,col,No] = size(outputMatrix);
            if (Sr>row)||(Sc>col)
                error('Sr or Sc too large');
            end
%             new_outMatrix = maxPooling2dLayer([Sr,Sc]);
            new_outputMatrix = zeros(round(row/Sr),round(col/Sc),No);
            row_count=1;
            col_count=1;
            max = 0;
            for n=1:No
                for r=1:Sr:row
                    for c=1:Sc:col
                       for rr=1:r
                           for cc=1:c
                               if(outputMatrix(rr,cc,n) > max)
                                   max = outputMatrix(rr,cc,n);
                               end
                           end
                       end
                       new_outputMatrix(row_count,col_count,n) = max;
                       col_count = col_count + 1;
                    end
                    row_count = row_count + 1;
                    col_count = 1;
                end
                row_count = 1;
            end
        end
    end
end

